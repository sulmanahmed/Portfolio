import React from "react";
import style from "./Navbar.module.css";
import { Link } from "react-router-dom";
import Button from "../Button";
import MenuIcon from "@mui/icons-material/Menu";

const Navbar = () => {
  return (
    <header>
      <div className="container">
        <div className={style.header_wrapper}>
          <Link to="/" className={style.logo}>
            Portfolio
          </Link>
          <MenuIcon className={style.menuicon} />
          <nav>
            <ul className={style.nav_links}>
              <li>
                <Link to="/">About</Link>
              </li>
              <li>
                <Link to="/">Portfolio</Link>
              </li>
              <li>
                <Link to="/">Contact</Link>
              </li>
            </ul>
          </nav>
          <Link to="/" className={style.cta}>
            <Button text="Get Started" />
          </Link>
        </div>
      </div>
    </header>
  );
};

export default Navbar;
